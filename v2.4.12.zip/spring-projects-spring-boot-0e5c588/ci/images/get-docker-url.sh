#!/bin/bash
set -e

version="20.10.9"
echo "https://download.docker.com/linux/static/stable/x86_64/docker-$version.tgz";
